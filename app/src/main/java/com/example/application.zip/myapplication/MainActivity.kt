package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.Animals.AnimalBear
import com.example.myapplication.Animals.AnimalCat
import com.example.myapplication.Animals.AnimalCheetah
import com.example.myapplication.Animals.AnimalDog
import com.example.myapplication.Animals.AnimalElephant
import com.example.myapplication.Animals.AnimalFox
import com.example.myapplication.Animals.AnimalGriraffe
import com.example.myapplication.Animals.AnimalJackal
import com.example.myapplication.Animals.AnimalLion
import com.example.myapplication.Animals.AnimalTiger
import com.example.myapplication.Animals.AnimalWolf
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {

                // Start navigation
                val navController = rememberNavController()
                NavHost(navController = navController, startDestination = "main") {
                    composable("main") {
                        Animal(navController)
                    }
                    composable("animalDog") {
                        AnimalDog()
                        }
                    composable("cat") {
                        AnimalCat()
                    }
                    composable("cheetah") {
                        AnimalCheetah()
                    }
                    composable("cheetah") {
                        AnimalCheetah()
                    }
                    composable("jackal") {
                        AnimalJackal()
                    }
                    composable("giraffe") {
                        AnimalGriraffe()
                    }
                    composable("elephant") {
                        AnimalElephant()
                    }
                    composable("bear") {
                        AnimalBear()
                    }
                    composable("bear") {
                        AnimalBear()
                    }
                    composable("fox") {
                        AnimalFox()
                    }
                    composable("lion") {
                        AnimalLion()
                    }
                    composable("wolf") {
                        AnimalWolf()
                    }
                    composable("tiger") {
                        AnimalTiger()
                    }

            }
        }
    }
}
@Composable
fun MainScreen(navController: NavHostController) {
    Column {
        // Icon to navigate to AnimalDog
        IconButton(
            onClick = {
                navController.navigate("animalDog") // Navigate to AnimalDog screen
            },
            modifier = Modifier
                .padding(start = 163.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = "Favorite",
                tint = Color.DarkGray,
                modifier = Modifier.size(35.dp)
            )
        }
    }
}
@Composable
fun Animal(navController: NavHostController) {

    val items = listOf("About")
    val selectedItem = remember { mutableStateOf(items[0]) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(200.dp)
                    .clip(
                        RoundedCornerShape(
                            topStart = 20.dp,
                            topEnd = 20.dp
                        )
                    )
                    .background(Color(0xFFad8045))

            ) {
                Row(modifier = Modifier
                    .padding(5.dp)
                    .padding(top = 20.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.logo),
                        contentDescription = "ImG", contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(55.dp)
                            .clip(RoundedCornerShape(15.dp))
                    )
                    Column(
                        modifier = Modifier
                            .padding(start = 5.dp)
                    ) {
                        Text("Jalilov",Modifier.padding(top=20.dp))
                        Text("Muhammadamin")

                    }
                }
                items.forEach { item ->
                    TextButton(
                        onClick = {
                            scope.launch { drawerState.close() }
                            selectedItem.value = item
                        },
                        colors = ButtonDefaults.buttonColors(
                            contentColor = Color.Black,
                            containerColor = Color.Transparent
                        )
                    ) {


                        Text(
                            item,
                            fontSize = 30.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top=5.dp)
                                .background(Color(0xFFad8045))
                                .height(40.dp)

                        )
                    }
                }
            }
        },

        content = {
            Column {
                Column(
                    modifier = Modifier

                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()

                            .background(Color(0xFF8f5100))
                            .padding(top = 30.dp)
                            .height(50.dp)

                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            IconButton(onClick = {
                                scope.launch { drawerState.open() }
                            }) {
                                Icon(Icons.Filled.Menu, "Меню", tint = Color.White)


                            }


                            Text(
                                "Animal",
                                Modifier.padding(start = 20.dp),
                                fontSize = 32.sp,
                                fontStyle = FontStyle.Italic,
                                color = Color.White
                            )
                            Image(
                                painter = painterResource(id = R.drawable.ico),
                                contentDescription = "ImG", contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .padding(5.dp)
                                    .padding(start = 150.dp)
                                    .size(35.dp)
                                    .clip(RoundedCornerShape(15.dp))
                            )
                        }
                    }
                    Column(
                        modifier = Modifier
                            .verticalScroll(rememberScrollState())
                    ) {

                        //Tiger
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFf4e9c7))
                                .height(80.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.a2),
                                contentDescription = "ImG", contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .padding(5.dp)
                                    .size(65.dp)
                                    .clip(shape = RoundedCornerShape(15.dp))
                            )
                            Text(
                                "Tiger",
                                fontSize = 30.sp,
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.Bold,
                                color = Color.DarkGray
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Favorite",
                                tint = Color.DarkGray, modifier = Modifier
                                    .padding(start = 163.dp)
                                    .size(35.dp)
                                    .clickable {navController.navigate("tiger") }

                            )
                        }
                        //Wolf
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top=3.dp)
                                .background(Color(0xFFf4e9c7))
                                .height(80.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.an2),
                                contentDescription = "ImG", contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .padding(5.dp)
                                    .size(65.dp)
                                    .clip(shape = RoundedCornerShape(15.dp))
                            )
                            Text(
                                "Wolf",
                                fontSize = 30.sp,
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.Bold,
                                color = Color.DarkGray
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Favorite",
                                tint = Color.DarkGray, modifier = Modifier
                                    .padding(start = 170.dp)
                                    .size(35.dp)
                                    .clickable {navController.navigate("wolf") }

                            )
                        }
                        //Lion an3
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top=3.dp)
                                .background(Color(0xFFf4e9c7))
                                .height(80.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.an3),
                                contentDescription = "ImG", contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .padding(5.dp)
                                    .size(65.dp)
                                    .clip(shape = RoundedCornerShape(15.dp))
                            )
                            Text(
                                "Lion",
                                fontSize = 30.sp,
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.Bold,
                                color = Color.DarkGray
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Favorite",
                                tint = Color.DarkGray, modifier = Modifier
                                    .padding(start = 170.dp)
                                    .size(35.dp)
                                    .clickable {navController.navigate("lion") }

                            )
                        }
                        // Fox an4
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top=3.dp)
                                .background(Color(0xFFf4e9c7))
                                .height(80.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.an4),
                                contentDescription = "ImG", contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .padding(5.dp)
                                    .size(65.dp)
                                    .clip(shape = RoundedCornerShape(15.dp))
                            )
                            Text(
                                "Fox",
                                fontSize = 30.sp,
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.Bold,
                                color = Color.DarkGray
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Favorite",
                                tint = Color.DarkGray, modifier = Modifier
                                    .padding(start = 180.dp)
                                    .size(35.dp)
                                    .clickable { navController.navigate("fox")}

                            )
                        }
                        // Bear a5
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top=3.dp)
                                .background(Color(0xFFf4e9c7))
                                .height(80.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.a5),
                                contentDescription = "ImG", contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .padding(5.dp)
                                    .size(65.dp)
                                    .clip(shape = RoundedCornerShape(15.dp))
                            )
                            Text(
                                "Bear",
                                fontSize = 30.sp,
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.Bold,
                                color = Color.DarkGray
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Favorite",
                                tint = Color.DarkGray, modifier = Modifier
                                    .padding(start = 165.dp)
                                    .size(35.dp)
                                    .clickable { navController.navigate("bear")}

                            )
                        }
                        // elephant A6
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top=3.dp)
                                .background(Color(0xFFf4e9c7))
                                .height(80.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.a6),
                                contentDescription = "ImG", contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .padding(5.dp)
                                    .size(65.dp)
                                    .clip(shape = RoundedCornerShape(15.dp))
                            )
                            Text(
                                "Elephant",
                                fontSize = 30.sp,
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.Bold,
                                color = Color.DarkGray
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Favorite",
                                tint = Color.DarkGray, modifier = Modifier
                                    .padding(start = 117.dp)
                                    .size(35.dp)
                                    .clickable {navController.navigate("elephant") }

                            )
                        }
                        //Girafe a7 a8 a88
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top=3.dp)
                                .background(Color(0xFFf4e9c7))
                                .height(80.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.a8),
                                contentDescription = "ImG", contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .padding(5.dp)
                                    .size(65.dp)
                                    .clip(shape = RoundedCornerShape(15.dp))
                            )
                            Text(
                                "Giraffe",
                                fontSize = 30.sp,
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.Bold,
                                color = Color.DarkGray
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Giraffe",
                                tint = Color.DarkGray, modifier = Modifier
                                    .padding(start = 140.dp)
                                    .size(35.dp)
                                    .clickable {navController.navigate("giraffe")}

                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top=3.dp)
                                .background(Color(0xFFf4e9c7))
                                .height(80.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.a9),
                                contentDescription = "ImG", contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .padding(5.dp)
                                    .size(65.dp)
                                    .clip(shape = RoundedCornerShape(15.dp))
                            )
                            Text(
                                "Jackal",
                                fontSize = 30.sp,
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.Bold,
                                color = Color.DarkGray
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Giraffe",
                                tint = Color.DarkGray, modifier = Modifier
                                    .padding(start = 145.dp)
                                    .size(35.dp)
                                    .clickable {navController.navigate("jackal") }

                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top=3.dp)
                                .background(Color(0xFFf4e9c7))
                                .height(80.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.a10),
                                contentDescription = "ImG", contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .padding(5.dp)
                                    .size(65.dp)
                                    .clip(shape = RoundedCornerShape(15.dp))
                            )
                            Text(
                                "Cheetah",
                                fontSize = 30.sp,
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.Bold,
                                color = Color.DarkGray
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "cheeteh",
                                tint = Color.DarkGray, modifier = Modifier
                                    .padding(start = 120.dp)
                                    .size(35.dp)
                                    .clickable { navController.navigate("cheetah")}

                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top=3.dp)
                                .background(Color(0xFFf4e9c7))
                                .height(80.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.a11),
                                contentDescription = "ImG", contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .padding(5.dp)
                                    .size(65.dp)
                                    .clip(shape = RoundedCornerShape(15.dp))
                            )
                            Text(
                                "Dog",
                                fontSize = 30.sp,
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.Bold,
                                color = Color.DarkGray
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "cheeteh",
                                tint = Color.DarkGray, modifier = Modifier
                                    .padding(start = 175.dp)
                                    .size(35.dp)
                                    .clickable {
                                    navController.navigate("animalDog") // Navigate to AnimalDog screen
                                }

                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top=3.dp)
                                .background(Color(0xFFf4e9c7))
                                .height(80.dp), verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.a12),
                                contentDescription = "ImG", contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .padding(5.dp)
                                    .size(65.dp)
                                    .clip(shape = RoundedCornerShape(15.dp))
                            )
                            Text(
                                "Cat",
                                fontSize = 30.sp,
                                fontStyle = FontStyle.Italic,
                                fontWeight = FontWeight.Bold,
                                color = Color.DarkGray
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Cat",
                                tint = Color.DarkGray, modifier = Modifier
                                    .padding(start = 180.dp)
                                    .size(35.dp)
                                    .clickable { navController.navigate("cat")}

                            )
                        }

                    }
                }
            }
        }
    )
}
